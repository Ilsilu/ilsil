
immutable_var = (1, 2, 3, 4, 5, 6,)
print(immutable_var)
mutable_list = ([3, 4, 5,],6)
mutable_list[0][1] = 100
print(mutable_list)